let update_Month = "11";
let update_Day = "05";
let update_Year = "2026";

let versionNumber = update_Year + "." + update_Month + "." + update_Day;

document.getElementById("stat-version").innerHTML = versionNumber;